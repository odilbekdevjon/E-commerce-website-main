
const regions = {
    
    andijon: {
        title1:"Oltinkoʻl",
        title2:"Baliqchi",
        title3:"Voroshilov",
        title4:"Jalaquduq",
        title5:"Izboskan",
        title6:"Lenin",
        title7:"Marhamat",
    },
    buxoro: {
        title1:"Vobkent",
        title2:"Jondor",
        title3:"Kogon",
        title4:"Olot",
        title5:"Peshkoʻpiri",
        title6:"Romitan",
        title7:"Shofirkon",
        title8:"Qorovulbozor",
        title9:"Qorakoʻl",
        title10:"Gʻijduvon",
    }
}

export default regions;