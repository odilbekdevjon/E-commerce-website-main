const newRegions = {
    andijon: ["Oltinkoʻl", "Baliqchi",  "Voroshilov"],
    buxoro: ["Vobkent", "Kogon"]
}

export default newRegions;